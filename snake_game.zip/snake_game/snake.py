from turtle import Turtle

STARTING_POSITIONS = [(0, 0), (-10, 0), (-20, 0)]
# SEGMENTS = []

class Snake:
    def __init__(self):
        self.segments = []
        self.create_snake()
        self.head = self.segments[0]

    def create_snake(self):
        # global SEGMENTS
        global STARTING_POSITIONS
        for positions in STARTING_POSITIONS:
            new_segment = Turtle("square")
            new_segment.penup()
            new_segment.shapesize(0.5, 0.5)
            new_segment.color("white")
            new_segment.goto(positions)
            self.segments.append(new_segment)

    def move(self):
        for seg in range(len(self.segments) - 1, 0, -1):
            new_x = self.segments[seg - 1].xcor()
            new_y = self.segments[seg - 1].ycor()

            self.segments[seg].goto(new_x, new_y)

        self.head.forward(10)

    def up(self):
        if self.head.heading != 270:
            self.head.setheading(90)

    def down(self):
        self.head.setheading(270)

    def right(self):
        self.head.setheading(360)

    def left(self):
        self.head.setheading(180)

